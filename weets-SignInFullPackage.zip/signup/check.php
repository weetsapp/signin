<?php


include '../config.php';

$username = $_POST['username'];
$pasword = $_POST['pasword'];
$firstname = $_POST['firstname'];
$surname = $_POST['surname'];


    $u = "INSERT INTO `signin` (`username`, `pasword`, `firstname`, `surname`) VALUES ('$username', '$pasword', '$firstname', '$surname')";
    
    $u1 = mysqli_query($con, $u);
    if($u1){
        echo "SUCCESS";
    }
    else{
        echo "FAIL";
    }
    





?>